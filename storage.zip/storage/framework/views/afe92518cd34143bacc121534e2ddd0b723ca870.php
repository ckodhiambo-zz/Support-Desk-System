<div>
    
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Skydash Admin</title>
        <!-- Styles -->
        <!-- Plugin css for this page -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
              integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
              crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
              integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
              crossorigin="anonymous">
        <link rel="stylesheet"
              href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/feather/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">
        <!-- endinject -->
        <!-- Plugin css for this page -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/js/select.dataTables.min.css')); ?>">
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/vertical-layout-light/style.css')); ?>">
        <!-- endinject -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>"/>
        <!-- Template Main CSS File -->
        <link href="<?php echo e(asset('website-assets/css/style.css')); ?>" rel="stylesheet">
        <style>
            .l-bg-cherry {
                background: linear-gradient(to right, #8d188e, #0d47a1) !important;
                color: #fff;
            }
        </style>

        <?php echo \Livewire\Livewire::styles(); ?>

    </head>

    <body>
    <div class="col-12 grid-margin">
        <br>
        <div class="card card-outline-primary">
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <div class="card border-primary mb-3" style="border-color: #8d188e !important;">
                            <div class="card-header l-bg-cherry" style="border-radius: 10px">
                                <h5>My Raised Tickets</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="card-description">
                    Tickets are in <code>an ascending order.</code>
                </p>
                <?php if(Session::has('message_sent')): ?>
                    <div class="alert alert-info" role="alert">
                        <?php echo e(Session::get('message_sent')); ?>

                    </div>
                <?php endif; ?>
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active text-dark" id="new-tab" data-toggle="tab" href="#new"
                           role="tab" aria-controls="home" aria-selected="true">New</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-info" id="open-tab" data-toggle="tab" href="#open"
                           role="tab" aria-controls="home" aria-selected="true">Open</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-primary" id="in-progress-tab" data-toggle="tab" href="#in-progress"
                           role="tab" aria-controls="home" aria-selected="true">In-Progress</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-warning" id="pending-tab" data-toggle="tab" href="#pending"
                           role="tab" aria-controls="profile" aria-selected="false">On-Hold</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-success" id="solved-tab" data-toggle="tab" href="#solved"
                           role="tab"
                           aria-controls="contact" aria-selected="false">Solved</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark" id="partially-solved-tab" data-toggle="tab"
                           href="#partially-solved"
                           role="tab"
                           aria-controls="contact" aria-selected="false">Partially Solved</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-danger" id="cancelled-tab" data-toggle="tab" href="#cancelled"
                           role="tab" aria-controls="contact" aria-selected="false">Cancelled</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-info" id="archived-tab" data-toggle="tab" href="#archived"
                           role="tab"
                           aria-controls="contact" aria-selected="false">Archived</a>
                    </li>
                </ul>

                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active " id="new" role="tabpanel" aria-labelledby="new-tab">
                        <div class="table-responsive">
                            <table id="example3" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-dark"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="open" role="tabpanel" aria-labelledby="open-tab">
                        <div class="table-responsive">
                            <table id="example32" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $open; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-info"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="in-progress" role="tabpanel" aria-labelledby="in-progress-tab">
                        <div class="table-responsive">
                            <table id="example16" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $in_progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-dark"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="pending" role="tabpanel" aria-labelledby="pending-tab">
                        <div class="table-responsive">
                            <table id="example17" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $on_hold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-dark"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="partially-solved" role="tabpanel"
                         aria-labelledby="partially-solved-tab">
                        <div class="table-responsive">
                            <table id="example18" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $partially_solved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-dark"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="solved" role="tabpanel" aria-labelledby="solved-tab">
                        <div class="table-responsive">
                            <table id="example6" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $solved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-dark"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="cancelled" role="tabpanel" aria-labelledby="cancelled-tab">
                        <div class="table-responsive">
                            <table id="example19" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $cancelled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-danger"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="archived" role="tabpanel" aria-labelledby="archived-tab">
                        <div class="table-responsive">
                            <table id="example20" class="table table-striped">
                                <thead>
                                <tr>
                                    <th>
                                        T-ID
                                    </th>
                                    <th>
                                        Issue
                                    </th>
                                    <th>
                                        Asset
                                    </th>
                                    <th>
                                        Created_at
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Action
                                    </th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $archived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="py-1">
                                            <?php echo e($ticket->id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->issue); ?>

                                        </td>
                                        <td>
                                            <?php echo e(\App\Models\Asset::find($ticket->asset_name)->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                        <td>
                                            <label class="badge badge-info"
                                                   style=" font-size: 0.9em;color: white"><strong><?php echo e($ticket->status->name); ?></strong></label>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('employee.ticket-detail', $ticket)); ?>"
                                               class="btn btn-outline-info btn-sm btn-fw">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example3').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example32').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example6').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example20').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example19').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example18').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example17').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('#example16').DataTable();
        });
    </script>
    </body>

    </html>
</div>
<?php /**PATH C:\xampp\htdocs\skydesk-app\resources\views/livewire/employee/tickets-component.blade.php ENDPATH**/ ?>